var e = document.createElement('div');
e.id = 'MWUOvoYpNAmf';
e.style.display = 'none';
document.body.appendChild(e);
setTimeout(() => {
    document.body.removeChild(e);
}, 2000);